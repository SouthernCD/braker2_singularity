# Example data

See the [Example data](https://github.com/Gaius-Augustus/BRAKER#example-data) section of 
the [BRAKER user guide](https://github.com/Gaius-Augustus/BRAKER#braker-user-guide) for 
the description of tests and example data in this folder
